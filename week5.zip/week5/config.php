<?php
$link = mysql_connect('mysql-user-master.stanford.edu', 'ccs147zdocena', 'ixaedoit');
mysql_select_db('c_cs147_zdocena');
?>